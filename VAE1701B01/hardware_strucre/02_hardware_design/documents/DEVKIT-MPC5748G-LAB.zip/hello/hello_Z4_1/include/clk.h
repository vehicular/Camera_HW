/*
 * clk.h
 *
 *  Created on: Feb 24, 2016
 *      Author: B55457
 */

#ifndef CLK_H_
#define CLK_H_

#include "project.h"

void clock_out_FMPLL();

void clock_out_FIRC();


#endif /* CLK_H_ */
