/*
 * mode.h
 *
 *  Created on: Feb 25, 2016
 *      Author: B55457
 */

#ifndef MODE_H_
#define MODE_H_

#include "project.h"

void PLL_160MHz (void);
void system160mhz (void);
void enter_STOP_mode (void);

#endif /* MODE_H_ */
