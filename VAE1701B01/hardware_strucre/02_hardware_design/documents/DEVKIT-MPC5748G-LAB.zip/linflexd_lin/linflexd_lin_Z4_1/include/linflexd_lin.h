/*
 * linflexd_lin.h
 *
 *  Created on: Mar 2, 2016
 *      Author: B55457
 */

#ifndef LINFLEXD_LIN_H_
#define LINFLEXD_LIN_H_

#include "derivative.h"
#include "project.h"

void initLINFlexD_0 (void);
void transmitLINframe (void);
void receiveLINframe(void);


#endif /* LINFLEXD_LIN_H_ */
